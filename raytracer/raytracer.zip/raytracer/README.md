Python - Raytracer
================= 

Dies ist ein einfacher Raytacer geschrieben in Python. Realisiert wird eine Szene mit drei Kugeln, einer Ebene und einer Lichtquelle rechts oben.

Zum Start des Programm´s muss die Datei 'Scene.py' ausgefuehrt werden.


Das gerenderte Bild wird anschliessend im Verzeichnis 'img_export' gespeichert. Bei groesserer Aufloesung kann es sein, dass das Rendern mehrere Minuten dauern kann.



Eine Beispielszene sieht wie folgt aus:

<img src="https://raw.github.com/kroell/hsrm-mi-6semester-gencg/master/raytracer/img_export/raytracer_scene.png" title="Demo-Szene"> </img>
